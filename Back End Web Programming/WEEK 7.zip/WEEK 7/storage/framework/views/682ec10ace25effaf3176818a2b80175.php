<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        <?php if (! empty(trim($__env->yieldContent('styles')))): ?>
            <?php echo $__env->yieldContent('styles'); ?>
        <?php endif; ?>

    </style>
</head>
<body>
    <?php echo $__env->make('component.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <main class="flex-grow">
        <?php echo $__env->yieldContent('content'); ?>
    </main>

    <?php echo $__env->make('component.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</body>
</html>     



<?php /**PATH C:\Users\ferli\Desktop\Documents\Kuliah\Praktikum-ISTTS\Back End Web Programming\WEEK 7\resources\views/template/template.blade.php ENDPATH**/ ?>